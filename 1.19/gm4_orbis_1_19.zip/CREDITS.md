# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- [Misode](https://twitter.com/misode_)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
