# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Misode](https://twitter.com/misode_)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [kyrkis](http://discordapp.com/users/287287322360414218)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
