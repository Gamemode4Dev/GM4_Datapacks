# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz

## Textures
- [Kyrius](http://discordapp.com/users/287287322360414218)
