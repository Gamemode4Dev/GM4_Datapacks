tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Reeling Rods]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Reeling Rods",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.reeling_rods",fallback:"Steal Villager's wares, scratch up your foes! Fishing rods have never been more useful!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:reeling_rods/display/reeling
function gm4_guidebook:reeling_rods/rewards/unlock/reeling
