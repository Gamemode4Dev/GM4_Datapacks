execute if entity @s[advancements={gm4_guidebook:calling_bell/unlock/calling=true}] run function gm4_guidebook:calling_bell/rewards/unlock/calling
return 1
