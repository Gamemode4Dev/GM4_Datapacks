tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Dripleaf Filters]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Dripleaf Filters",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.dripleaf_filters",fallback:"Dripleaves will flick items that match a hopper's contents into the hopper for you!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:dripleaf_filters/display/usage
function gm4_guidebook:dripleaf_filters/rewards/unlock/usage
