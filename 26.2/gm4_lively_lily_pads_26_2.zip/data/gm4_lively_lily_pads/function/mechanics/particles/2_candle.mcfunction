# displays flames for a 2 candle display
# @s = candle display
# at @s
# run from mechanics/particles/candle_count

particle small_flame ~0.1 ~0.42 ~-0.05
particle small_flame ~-0.1 ~0.37 ~
execute if score $rand gm4_llp.data matches 1 run particle smoke ~0.1 ~0.43 ~-0.05
execute if score $rand gm4_llp.data matches 2 run particle smoke ~-0.1 ~0.38 ~
