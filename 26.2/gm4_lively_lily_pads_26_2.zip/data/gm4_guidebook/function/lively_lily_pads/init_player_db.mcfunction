execute if entity @s[advancements={gm4_guidebook:lively_lily_pads/unlock/display=true}] run function gm4_guidebook:lively_lily_pads/rewards/unlock/display
return 1
