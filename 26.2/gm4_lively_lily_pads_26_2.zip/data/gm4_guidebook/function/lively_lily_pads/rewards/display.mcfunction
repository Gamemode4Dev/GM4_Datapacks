tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Lively Lily Pads]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Lively Lily Pads",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.lively_lily_pads",fallback:"Place decorations on Lily Pads!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:lively_lily_pads/display/display
function gm4_guidebook:lively_lily_pads/rewards/unlock/display
