execute if entity @s[advancements={gm4_guidebook:tipped_skeletons/unlock/description=true}] run function gm4_guidebook:tipped_skeletons/rewards/unlock/description
return 1
