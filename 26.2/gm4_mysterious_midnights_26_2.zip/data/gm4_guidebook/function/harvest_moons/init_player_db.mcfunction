execute if entity @s[advancements={gm4_guidebook:harvest_moons/unlock/description=true}] run function gm4_guidebook:harvest_moons/rewards/unlock/description
return 1
