execute if entity @s[advancements={gm4_guidebook:resurrecting_zombies/unlock/description=true}] run function gm4_guidebook:resurrecting_zombies/rewards/unlock/description
return 1
