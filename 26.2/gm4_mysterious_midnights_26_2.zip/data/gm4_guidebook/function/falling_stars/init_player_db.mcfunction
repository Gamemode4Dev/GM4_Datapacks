execute if entity @s[advancements={gm4_guidebook:falling_stars/unlock/description=true}] run function gm4_guidebook:falling_stars/rewards/unlock/description
return 1
