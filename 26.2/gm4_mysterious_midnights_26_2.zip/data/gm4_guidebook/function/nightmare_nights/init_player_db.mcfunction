execute if entity @s[advancements={gm4_guidebook:nightmare_nights/unlock/description=true}] run function gm4_guidebook:nightmare_nights/rewards/unlock/description
execute unless score gm4_midnight_menaces load.status matches 1.. if entity @s[advancements={gm4_guidebook:nightmare_nights/unlock/events=true}] run function gm4_guidebook:nightmare_nights/rewards/unlock/events
execute if score gm4_midnight_menaces load.status matches 1.. if entity @s[advancements={gm4_guidebook:nightmare_nights/unlock/events_with_menaces=true}] run function gm4_guidebook:nightmare_nights/rewards/unlock/events_with_menaces
return 1
