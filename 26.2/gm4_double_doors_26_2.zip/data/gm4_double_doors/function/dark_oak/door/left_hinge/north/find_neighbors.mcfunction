# Checks for neighboring doors which may also have to be opened alongside this door.
# @s = player that interacted with a door
# at location of the lower half of the door the player has interacted with
# run from gm4_double_doors:dark_oak/door/left_hinge/get_facing

# open this door
function gm4_double_doors:dark_oak/door/left_hinge/north/toggle

# check for potential neighbouring doors which should also be opened, this neighbor has to be of the opposite hinge
execute positioned ~1 ~ ~ if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=north] run function gm4_double_doors:dark_oak/door/right_hinge/north/toggle
execute positioned ~ ~ ~-1 if block ~ ~ ~ minecraft:dark_oak_door[hinge=right, facing=south] run function gm4_double_doors:dark_oak/door/right_hinge/south/toggle
