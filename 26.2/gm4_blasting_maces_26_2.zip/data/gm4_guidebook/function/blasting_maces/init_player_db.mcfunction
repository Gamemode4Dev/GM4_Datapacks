execute if entity @s[advancements={gm4_guidebook:blasting_maces/unlock/description=true}] run function gm4_guidebook:blasting_maces/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:blasting_maces/unlock/usage=true}] run function gm4_guidebook:blasting_maces/rewards/unlock/usage
return 1
