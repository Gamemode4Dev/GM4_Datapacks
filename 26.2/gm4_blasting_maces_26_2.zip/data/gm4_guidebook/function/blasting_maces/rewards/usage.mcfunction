tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Blasting Maces]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Blasting Maces",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.blasting_maces",fallback:"Why break one block when you can break nine? Now maces hit harder than ever!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:blasting_maces/display/usage
function gm4_guidebook:blasting_maces/rewards/unlock/usage
