execute if entity @s[advancements={gm4_guidebook:undead_players/unlock/description=true}] run function gm4_guidebook:undead_players/rewards/unlock/description
return 1
