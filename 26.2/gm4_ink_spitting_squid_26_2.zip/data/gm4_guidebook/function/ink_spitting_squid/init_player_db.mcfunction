execute if entity @s[advancements={gm4_guidebook:ink_spitting_squid/unlock/normal_squid=true}] run function gm4_guidebook:ink_spitting_squid/rewards/unlock/normal_squid
execute if entity @s[advancements={gm4_guidebook:ink_spitting_squid/unlock/glow_squid=true}] run function gm4_guidebook:ink_spitting_squid/rewards/unlock/glow_squid
return 1
