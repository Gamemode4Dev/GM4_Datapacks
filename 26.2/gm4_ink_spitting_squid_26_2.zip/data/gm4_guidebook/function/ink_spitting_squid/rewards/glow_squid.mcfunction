tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Ink Spitting Squid]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Ink Spitting Squid",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.ink_spitting_squid",fallback:"Improves the vanilla ink effect by adding Blindness. Glow Squid will give Night Vision when disturbed, which might come in handy if you're out of torches!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:ink_spitting_squid/display/glow_squid
advancement grant @s only gm4_guidebook:ink_spitting_squid/unlock/normal_squid
function gm4_guidebook:ink_spitting_squid/rewards/unlock/glow_squid
