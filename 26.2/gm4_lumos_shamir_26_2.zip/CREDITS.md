# Credits

## Creators
- InternetAlien
- [SirSheepe](https://bsky.app/profile/sirsheepe.bsky.social)

## Idea By
- [Misode](https://bsky.app/profile/misode.dev)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
