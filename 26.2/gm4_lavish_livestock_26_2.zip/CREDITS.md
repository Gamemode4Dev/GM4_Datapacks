# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [runcows](https://bsky.app/profile/runcows.bsky.social)
