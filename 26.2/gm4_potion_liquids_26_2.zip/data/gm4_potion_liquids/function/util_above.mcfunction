tag @s add gm4_processing_tank
execute as @e[dx=0, type=shulker, tag=!smithed.entity] run function gm4_potion_liquids:util/shulker
execute as @e[dx=0, type=witch, tag=!smithed.entity] run function gm4_potion_liquids:util/witch
tag @s remove gm4_processing_tank
