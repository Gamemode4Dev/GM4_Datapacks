execute if entity @s[advancements={gm4_guidebook:sunken_treasure/unlock/details=true}] run function gm4_guidebook:sunken_treasure/rewards/unlock/details
return 1
