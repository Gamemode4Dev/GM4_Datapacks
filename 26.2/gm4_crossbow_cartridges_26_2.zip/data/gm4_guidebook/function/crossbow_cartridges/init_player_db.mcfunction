execute if entity @s[advancements={gm4_guidebook:crossbow_cartridges/unlock/available_ammo=true}] run function gm4_guidebook:crossbow_cartridges/rewards/unlock/available_ammo
return 1
