execute if entity @s[advancements={gm4_guidebook:survival_refightalized/unlock/armor=true}] run function gm4_guidebook:survival_refightalized/rewards/unlock/armor
execute if entity @s[advancements={gm4_guidebook:survival_refightalized/unlock/shield=true}] run function gm4_guidebook:survival_refightalized/rewards/unlock/shield
execute if entity @s[advancements={gm4_guidebook:survival_refightalized/unlock/mobs=true}] run function gm4_guidebook:survival_refightalized/rewards/unlock/mobs
return 1
