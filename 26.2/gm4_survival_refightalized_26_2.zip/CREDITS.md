# Credits

## Creator
- [Djones](https://bsky.app/profile/thanathor.bsky.social)

## Icon Design
- Hozz
