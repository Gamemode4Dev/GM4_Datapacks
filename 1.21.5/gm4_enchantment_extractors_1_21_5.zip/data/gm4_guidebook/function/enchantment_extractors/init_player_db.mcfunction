execute if entity @s[advancements={gm4_guidebook:enchantment_extractors/unlock/crafting=true}] run function gm4_guidebook:enchantment_extractors/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:enchantment_extractors/unlock/usage=true}] run function gm4_guidebook:enchantment_extractors/rewards/unlock/usage
return 1
