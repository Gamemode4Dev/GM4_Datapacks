# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- SunderB
- [Misode](https://bsky.app/profile/misode.dev)
- [JP12](https://github.com/jpeterik12)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
