# Credits

## Creator
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- Vilder50
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
