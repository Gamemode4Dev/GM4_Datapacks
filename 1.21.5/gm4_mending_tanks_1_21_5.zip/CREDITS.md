# Credits

## Creator
- [Kroppeb](https://tech.lgbt/@Kroppeb)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
