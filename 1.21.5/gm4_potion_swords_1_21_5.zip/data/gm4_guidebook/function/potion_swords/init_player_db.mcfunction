execute if entity @s[advancements={gm4_guidebook:potion_swords/unlock/usage=true}] run function gm4_guidebook:potion_swords/rewards/unlock/usage
return 1
