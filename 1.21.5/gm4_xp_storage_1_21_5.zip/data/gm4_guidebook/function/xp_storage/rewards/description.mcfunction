tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[XP Storage]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"XP Storage",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.xp_storage",fallback:"Stand on top of an Ender Chest to store Experience, stand below to retrieve it!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:xp_storage/display/description
function gm4_guidebook:xp_storage/rewards/unlock/description
