execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/default_recipes=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/default_recipes
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/gravel_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/gravel_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/sand_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/sand_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/red_sand_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/red_sand_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/amethyst_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/amethyst_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/dripstone_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/dripstone_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/quartz_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/quartz_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/string_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/string_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/cobweb_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/cobweb_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/horse_armor_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/horse_armor_recipe
execute if entity @s[advancements={gm4_guidebook:standard_crafting/unlock/enchanted_golden_apple_recipe=true}] run function gm4_guidebook:standard_crafting/rewards/unlock/enchanted_golden_apple_recipe
return 1
