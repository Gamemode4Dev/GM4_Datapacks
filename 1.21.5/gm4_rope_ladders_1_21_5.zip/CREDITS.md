# Credits

## Creator
- [Modulorium](https://www.modulorium.dev)

## Updated By
- [runcows](https://bsky.app/profile/runcows.bsky.social)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
