execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. if score gm4_metallurgy load.status matches 1 if score gm4_metallurgy_minor load.status matches 5.. run scoreboard players set gm4_vigere_shamir load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. if score gm4_metallurgy load.status matches 1 if score gm4_metallurgy_minor load.status matches 5.. run scoreboard players set gm4_vigere_shamir_minor load.status 5
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 8.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute unless score gm4_metallurgy load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Metallurgy",require_id:"gm4_metallurgy"}
execute if score gm4_metallurgy load.status matches 1.. unless score gm4_metallurgy load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Metallurgy",require_id:"gm4_metallurgy",require_ver:"1.5.0"}
execute if score gm4_metallurgy load.status matches 1 unless score gm4_metallurgy_minor load.status matches 5.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Vigere Shamir",id:"gm4_vigere_shamir",require:"Metallurgy",require_id:"gm4_metallurgy",require_ver:"1.5.0"}
execute unless score gm4_vigere_shamir load.status matches 1.. run scoreboard players set gm4_vigere_shamir load.status -1

execute if score gm4_vigere_shamir load.status matches 1 run function gm4_vigere_shamir:init
execute unless score gm4_vigere_shamir load.status matches 1 run schedule clear gm4_vigere_shamir:main
