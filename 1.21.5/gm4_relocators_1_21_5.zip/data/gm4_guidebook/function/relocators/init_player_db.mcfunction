execute if entity @s[advancements={gm4_guidebook:relocators/unlock/description=true}] run function gm4_guidebook:relocators/rewards/unlock/description
execute unless score gm4_book_binders load.status matches 1.. if entity @s[advancements={gm4_guidebook:relocators/unlock/crafting=true}] run function gm4_guidebook:relocators/rewards/unlock/crafting
execute if score gm4_book_binders load.status matches 1.. if entity @s[advancements={gm4_guidebook:relocators/unlock/crafting_book_binders=true}] run function gm4_guidebook:relocators/rewards/unlock/crafting_book_binders
execute if entity @s[advancements={gm4_guidebook:relocators/unlock/usage_pick_up=true}] run function gm4_guidebook:relocators/rewards/unlock/usage_pick_up
execute if entity @s[advancements={gm4_guidebook:relocators/unlock/usage_place_down=true}] run function gm4_guidebook:relocators/rewards/unlock/usage_place_down
return 1
