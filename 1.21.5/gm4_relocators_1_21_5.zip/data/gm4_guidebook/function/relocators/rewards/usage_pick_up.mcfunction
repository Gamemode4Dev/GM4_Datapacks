tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Relocators]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Relocators",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.relocators",fallback:"Craft Relocators to pick up and move containers such as chests and Custom Crafters.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:relocators/display/usage_pick_up
advancement grant @s only gm4_guidebook:relocators/unlock/description
function gm4_guidebook:relocators/rewards/unlock/usage_pick_up
