tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Forming Press]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Forming Press",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.forming_press",fallback:"Create a Forming Press to unlock more efficient recipes for all types of brick and Charcoal.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:forming_press/display/crafting
function gm4_guidebook:forming_press/rewards/unlock/crafting
