data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "forming_press"
data modify storage gm4_guidebook:temp unlocking.target_page set value 15
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 20
data modify storage gm4_guidebook:temp unlocking.source_page set value "end_recipes_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 16
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 21
data modify storage gm4_guidebook:temp unlocking.source_page set value "end_recipes_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
