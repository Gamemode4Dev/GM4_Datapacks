execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/description=true}] run function gm4_guidebook:forming_press/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/crafting=true}] run function gm4_guidebook:forming_press/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/first_recipe=true}] run function gm4_guidebook:forming_press/rewards/unlock/first_recipe
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/overworld_brick_recipes=true}] run function gm4_guidebook:forming_press/rewards/unlock/overworld_brick_recipes
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/wheat_recipes=true}] run function gm4_guidebook:forming_press/rewards/unlock/wheat_recipes
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/nether_recipes=true}] run function gm4_guidebook:forming_press/rewards/unlock/nether_recipes
execute if entity @s[advancements={gm4_guidebook:forming_press/unlock/end_recipes=true}] run function gm4_guidebook:forming_press/rewards/unlock/end_recipes
return 1
