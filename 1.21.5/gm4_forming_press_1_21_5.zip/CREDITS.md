# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)
- [BPR](https://bsky.app/profile/bpr02.com)
- TheEpyonProject

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
