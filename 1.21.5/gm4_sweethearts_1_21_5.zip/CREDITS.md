# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [BPR](https://bsky.app/profile/bpr02.com)
- [Thanathor](https://bsky.app/profile/thanathor.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
