execute if score gm4_player_motion load.status matches 1 if score gm4_player_motion_minor load.status matches 0 run function gm4_player_motion-1.0:load
execute unless score gm4_player_motion load.status matches 1 run schedule clear gm4_player_motion-1.0:internal/technical/tick
execute unless score gm4_player_motion_minor load.status matches 0 run schedule clear gm4_player_motion-1.0:internal/technical/tick
