# Credits

## Creators
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)
- [Denniss](https://github.com/Dennis-0)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
