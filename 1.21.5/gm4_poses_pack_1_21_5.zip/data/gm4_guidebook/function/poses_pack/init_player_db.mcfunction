execute if entity @s[advancements={gm4_guidebook:poses_pack/unlock/description=true}] run function gm4_guidebook:poses_pack/rewards/unlock/description
return 1
