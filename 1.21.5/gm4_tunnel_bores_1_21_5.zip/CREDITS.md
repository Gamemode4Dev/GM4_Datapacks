# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- Hozz
