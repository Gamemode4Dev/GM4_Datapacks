# Credits

## Creator
- [Djones](https://bsky.app/profile/thanathor.bsky.social)
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Tree Structures
- [BPR](https://bsky.app/profile/bpr02.com)
- rednls
- [Dinoguin_Jess](https://github.com/Dinoguin-Jess)
- [Lune6](https://bsky.app/profile/lune6.bsky.social)
