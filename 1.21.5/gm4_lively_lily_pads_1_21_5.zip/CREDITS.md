# Credits

## Creator
- [runcows](https://bsky.app/profile/runcows.bsky.social)

## Icon Design
- [runcows](https://bsky.app/profile/runcows.bsky.social)
