execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_lively_lily_pads load.status 3
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_lively_lily_pads_minor load.status 1
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Lively Lily Pads",id:"gm4_lively_lily_pads",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Lively Lily Pads",id:"gm4_lively_lily_pads",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 8.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Lively Lily Pads",id:"gm4_lively_lily_pads",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute unless score gm4_lively_lily_pads load.status matches 1.. run scoreboard players set gm4_lively_lily_pads load.status -1

execute if score gm4_lively_lily_pads load.status matches 3 run function gm4_lively_lily_pads:init
execute unless score gm4_lively_lily_pads load.status matches 3 run schedule clear gm4_lively_lily_pads:main
execute unless score gm4_lively_lily_pads load.status matches 3 run schedule clear gm4_lively_lily_pads:tick
