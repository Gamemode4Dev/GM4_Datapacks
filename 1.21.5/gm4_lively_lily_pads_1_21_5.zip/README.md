# <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="GM4 Logo" width="32" /> Lively Lily Pads by Gamemode 4

Place decorations on lily pads! 

<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/gm4_lively_lily_pads/images/lively_lily_pads.webp" alt="A spore blossom being placed on a lily pad" width="350"/>   

### Features
Place the following on lily pads:
- Candles*
- Lanterns*
- Torches*
- Coral Fans
- Cactus Flowers
- Spore Blossoms

\* Emit light. Candles need to be lit.

### More Info
[<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_wiki_logo.png" alt="Gamemode 4 Wiki Logo" width="40" align="center"/> **Read the Wiki**](https://wiki.gm4.co/wiki/Lively_Lily_Pads)

### Credits
- Creator: [runcows](https://bsky.app/profile/runcows.bsky.social)
- Icon Design: [runcows](https://bsky.app/profile/runcows.bsky.social)

---
## About Gamemode 4 <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="Gamemode 4 Logo" width="20"/>
Gamemode 4 is a series of command-powered creations that are designed to change and enhance the survival experience. All of our modules are designed to work together flawlessly, and are balanced for usage in a survival setting. Pick and choose your favorites from our [website](https://gm4.co), or wherever you get datapacks.