# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)

## Inspired by
- [SethBling](https://youtube.com/user/SethBling)

## Icon Design
- Hozz
