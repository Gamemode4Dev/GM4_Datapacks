execute if entity @s[advancements={gm4_guidebook:mountaineering/unlock/crafting=true}] run function gm4_guidebook:mountaineering/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:mountaineering/unlock/usage_crampons=true}] run function gm4_guidebook:mountaineering/rewards/unlock/usage_crampons
execute if entity @s[advancements={gm4_guidebook:mountaineering/unlock/usage_skis=true}] run function gm4_guidebook:mountaineering/rewards/unlock/usage_skis
execute if entity @s[advancements={gm4_guidebook:mountaineering/unlock/usage_poles=true}] run function gm4_guidebook:mountaineering/rewards/unlock/usage_poles
return 1
