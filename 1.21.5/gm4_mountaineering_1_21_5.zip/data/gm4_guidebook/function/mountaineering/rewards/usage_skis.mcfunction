tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Mountaineering]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Mountaineering",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.mountaineering",fallback:"A mezze of mountaineering means! Glide down slopes and scale cliffs.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:mountaineering/display/usage_skis
function gm4_guidebook:mountaineering/rewards/unlock/usage_skis
