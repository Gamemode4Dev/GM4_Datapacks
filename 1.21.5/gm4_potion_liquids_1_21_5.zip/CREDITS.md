# Credits

## Creator
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Textures by
- Vilder50

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
