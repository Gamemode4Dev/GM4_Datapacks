# Credits

## Creators
- [Bloo](https://bsky.app/profile/bloo.boo)
- [BPR](https://bsky.app/profile/bpr02.com)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
