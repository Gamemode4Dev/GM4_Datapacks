execute if entity @s[advancements={gm4_guidebook:apple_trees/unlock/obtaining_apples=true}] run function gm4_guidebook:apple_trees/rewards/unlock/obtaining_apples
execute if entity @s[advancements={gm4_guidebook:apple_trees/unlock/new_apples=true}] run function gm4_guidebook:apple_trees/rewards/unlock/new_apples
return 1
