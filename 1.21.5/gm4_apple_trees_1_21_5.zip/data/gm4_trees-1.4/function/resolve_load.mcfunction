execute if score gm4_trees load.status matches 1 if score gm4_trees_minor load.status matches 4 run function gm4_trees-1.4:load
execute unless score gm4_trees load.status matches 1 run schedule clear gm4_trees-1.4:tick
execute unless score gm4_trees_minor load.status matches 4 run schedule clear gm4_trees-1.4:tick
execute unless score gm4_trees load.status matches 1 run schedule clear gm4_trees-1.4:main
execute unless score gm4_trees_minor load.status matches 4 run schedule clear gm4_trees-1.4:main
