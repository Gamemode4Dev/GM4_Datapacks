# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- Federick90
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- Hozz
