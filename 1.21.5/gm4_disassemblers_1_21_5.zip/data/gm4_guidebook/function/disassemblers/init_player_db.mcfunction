execute if entity @s[advancements={gm4_guidebook:disassemblers/unlock/description=true}] run function gm4_guidebook:disassemblers/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:disassemblers/unlock/crafting=true}] run function gm4_guidebook:disassemblers/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:disassemblers/unlock/usage=true}] run function gm4_guidebook:disassemblers/rewards/unlock/usage
return 1
