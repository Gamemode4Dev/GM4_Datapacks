# Credits

## Creators
- [runcows](https://bsky.app/profile/runcows.bsky.social)
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [runcows](https://bsky.app/profile/runcows.bsky.social)
