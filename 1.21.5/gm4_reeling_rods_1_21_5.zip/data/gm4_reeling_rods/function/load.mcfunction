execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_reeling_rods load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 8.. run scoreboard players set gm4_reeling_rods_minor load.status 0
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Reeling Rods",id:"gm4_reeling_rods",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Reeling Rods",id:"gm4_reeling_rods",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 8.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Reeling Rods",id:"gm4_reeling_rods",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.8.0"}
execute unless score gm4_reeling_rods load.status matches 1.. run scoreboard players set gm4_reeling_rods load.status -1

execute if score gm4_reeling_rods load.status matches 1 run function gm4_reeling_rods:init
execute unless score gm4_reeling_rods load.status matches 1 run schedule clear gm4_reeling_rods:tick
