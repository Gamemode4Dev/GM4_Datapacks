execute if entity @s[advancements={gm4_guidebook:mob_curing/unlock/conversions=true}] run function gm4_guidebook:mob_curing/rewards/unlock/conversions
execute if entity @s[advancements={gm4_guidebook:mob_curing/unlock/potion_cleric=true}] run function gm4_guidebook:mob_curing/rewards/unlock/potion_cleric
return 1
