tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Mob Curing]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Mob Curing",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.mob_curing",fallback:"Revert mooshrooms, pigmen and witches back to their previous forms.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:mob_curing/display/potion_cleric
advancement grant @s only gm4_guidebook:mob_curing/unlock/conversions
function gm4_guidebook:mob_curing/rewards/unlock/potion_cleric
