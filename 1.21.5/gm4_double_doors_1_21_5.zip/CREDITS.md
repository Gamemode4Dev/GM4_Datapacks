# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- venomousbirds
