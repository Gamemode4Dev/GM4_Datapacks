# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
