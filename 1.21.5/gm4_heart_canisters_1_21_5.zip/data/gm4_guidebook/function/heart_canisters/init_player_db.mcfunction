execute if entity @s[advancements={gm4_guidebook:heart_canisters/unlock/crafting_tier_1=true}] run function gm4_guidebook:heart_canisters/rewards/unlock/crafting_tier_1
execute if entity @s[advancements={gm4_guidebook:heart_canisters/unlock/usage=true}] run function gm4_guidebook:heart_canisters/rewards/unlock/usage
return 1
