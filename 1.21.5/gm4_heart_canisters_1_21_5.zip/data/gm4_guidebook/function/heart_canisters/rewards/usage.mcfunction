tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Heart Canisters]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Heart Canisters",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.heart_canisters",fallback:"Introduces two tiers of pricey canisters that increase your health when carried.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:heart_canisters/display/usage
advancement grant @s only gm4_guidebook:heart_canisters/unlock/crafting_tier_1
function gm4_guidebook:heart_canisters/rewards/unlock/usage
