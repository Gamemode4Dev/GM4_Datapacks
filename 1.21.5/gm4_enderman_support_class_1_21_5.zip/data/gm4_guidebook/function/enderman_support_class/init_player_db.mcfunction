execute if entity @s[advancements={gm4_guidebook:enderman_support_class/unlock/buffs=true}] run function gm4_guidebook:enderman_support_class/rewards/unlock/buffs
return 1
