# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
