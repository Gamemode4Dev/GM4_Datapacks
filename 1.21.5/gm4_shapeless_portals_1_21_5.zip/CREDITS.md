# Credits

## Creator
- [Thanathor](https://bsky.app/profile/thanathor.bsky.social)

## Icon Design
- Hozz
