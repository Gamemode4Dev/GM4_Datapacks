# Credits

## Creators
- [Bunnygamers](https://bsky.app/profile/bunnygamers.bsky.social)
- [Misode](https://bsky.app/profile/misode.dev)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
