#@s = water tank liquid_tank_stand with item in first slot
#run from item_fill









    # "harness": "white_harness" # Added in 1.21.6,





execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:glass run function gm4_washing_tanks:washing_recipes/glass
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:glass_pane run function gm4_washing_tanks:washing_recipes/glass_pane
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:terracotta run function gm4_washing_tanks:washing_recipes/terracotta
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:wool run function gm4_washing_tanks:washing_recipes/wool
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:bed run function gm4_washing_tanks:washing_recipes/bed
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:carpet run function gm4_washing_tanks:washing_recipes/carpet

execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:shulker_box run function gm4_washing_tanks:washing_recipes/shulker_box
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:bundle run function gm4_washing_tanks:washing_recipes/bundle
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:candle run function gm4_washing_tanks:washing_recipes/candle
execute if items block ~ ~ ~ container.0 #gm4_washing_tanks:armour[dyed_color] run function gm4_washing_tanks:washing_recipes/armour


