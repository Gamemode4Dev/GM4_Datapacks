#@s = water tank liquid_tank_stand with item in first slot
#run from item_fill









    # "harness": "white_harness" # Added in 1.21.6,













scoreboard players set $item_value gm4_lt_value -1
item replace entity 00344d47-0004-0004-0004-000f04ce104d weapon.mainhand from block ~ ~ ~ container.0
item modify entity 00344d47-0004-0004-0004-000f04ce104d weapon.mainhand {function:"minecraft:set_components",components:{"!minecraft:dyed_color":{}}}
function gm4_liquid_tanks:smart_item_fill
tag @s add gm4_lt_fill
