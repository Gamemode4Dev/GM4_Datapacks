execute if entity @s[advancements={gm4_guidebook:better_fire/unlock/fire_changes=true}] run function gm4_guidebook:better_fire/rewards/unlock/fire_changes
return 1
