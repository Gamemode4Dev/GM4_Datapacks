# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated By
- [Bloo](https://bsky.app/profile/bloo.boo)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
