# Credits

## Creator
- [Djones](https://bsky.app/profile/thanathor.bsky.social)

## Icon Design
- Hozz

## Textures
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)
- rednls
