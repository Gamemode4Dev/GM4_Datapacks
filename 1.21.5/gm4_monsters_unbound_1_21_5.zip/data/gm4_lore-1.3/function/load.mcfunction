scoreboard objectives add gm4_lore dummy
execute unless score lore gm4_earliest_version matches ..103002 run scoreboard players set lore gm4_earliest_version 103002


data modify storage gm4:log versions append value {id:"gm4_lore",module:"lib_lore",version:"1.3.X",from:"Monsters Unbound"}
