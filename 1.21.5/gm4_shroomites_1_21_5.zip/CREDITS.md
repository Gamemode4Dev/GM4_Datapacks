# Credits

## Creators
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
