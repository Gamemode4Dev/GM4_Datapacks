execute if score @s gm4_lt_util matches 3.. run scoreboard players remove @s gm4_lt_value 3
execute if score @s gm4_lt_util matches 3.. run setblock ~ ~ ~ minecraft:powder_snow_cauldron[level=3]
execute if score @s gm4_lt_util matches 3.. run playsound item.bucket.empty_powder_snow block @a[distance=..10]
execute if score @s gm4_lt_util matches 3.. run scoreboard players remove @s gm4_lt_util 3
