execute if items block ~ ~ ~ container.0 * run function gm4_liquid_tanks:item_process
execute unless items block ~ ~ ~ container.0 * run tag @s remove gm4_lt_drain
execute unless items block ~ ~ ~ container.0 * run tag @s remove gm4_lt_fill
execute if block ~ ~ ~ hopper[enabled=true] align xyz positioned ~ ~1 ~ if entity @e[type=!armor_stand, dx=0] run function #gm4_liquid_tanks:util_above
execute if block ~ ~ ~ hopper[enabled=true] align xyz positioned ~ ~-1 ~ if entity @e[type=!armor_stand, dx=0] run function #gm4_liquid_tanks:util_below
execute unless score @s gm4_lt_prior_val = @s gm4_lt_value run function gm4_liquid_tanks:liquid_value_update
