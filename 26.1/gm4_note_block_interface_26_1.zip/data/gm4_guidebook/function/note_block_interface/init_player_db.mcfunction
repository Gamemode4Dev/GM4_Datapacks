execute if entity @s[advancements={gm4_guidebook:note_block_interface/unlock/description=true}] run function gm4_guidebook:note_block_interface/rewards/unlock/description
return 1
