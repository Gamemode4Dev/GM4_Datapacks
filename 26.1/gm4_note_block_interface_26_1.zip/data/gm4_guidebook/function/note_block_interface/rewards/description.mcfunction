tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Note Block Interface]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Note Block Interface",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.note_block_interface",fallback:"Adds a neat interface to improve your musical skills!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:note_block_interface/display/description
function gm4_guidebook:note_block_interface/rewards/unlock/description
