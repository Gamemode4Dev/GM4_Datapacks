execute if score gm4_lore load.status matches 1 unless score gm4_lore_minor load.status matches 4.. run scoreboard players set gm4_lore_minor load.status 4

execute unless score gm4_lore load.status matches 1.. run scoreboard players set gm4_lore_minor load.status 4
execute unless score gm4_lore load.status matches 1.. run scoreboard players set gm4_lore load.status 1
