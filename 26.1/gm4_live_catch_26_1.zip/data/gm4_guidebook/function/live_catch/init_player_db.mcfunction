execute if entity @s[advancements={gm4_guidebook:live_catch/unlock/description=true}] run function gm4_guidebook:live_catch/rewards/unlock/description
return 1
