tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Audere Shamir]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Audere Shamir",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.audere_shamir",fallback:"Adds the shamir 'Audere' to Metallurgy. Gain Haste with low durability tools.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:audere_shamir/display/usage
function gm4_guidebook:audere_shamir/rewards/unlock/usage
