execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. run scoreboard players set gm4_standard_crafting load.status 2
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 9.. run scoreboard players set gm4_standard_crafting_minor load.status 0
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Standard Crafting",id:"gm4_standard_crafting",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Standard Crafting",id:"gm4_standard_crafting",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 9.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Standard Crafting",id:"gm4_standard_crafting",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.9.0"}
execute unless score gm4_standard_crafting load.status matches 1.. run scoreboard players set gm4_standard_crafting load.status -1

execute if score gm4_standard_crafting load.status matches 2 run function gm4_standard_crafting:init
