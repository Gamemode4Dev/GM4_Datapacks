# @s = soul forge with multiblock
# run from main

# ambient particles
particle minecraft:soul_fire_flame ~ ~0.5 ~ 0.2 1 0.2 0.01 7
particle minecraft:soul ~ ~0.5 ~ 0.3 1 0.3 0.01 3

# colored smoke for ingredients
execute if score @s gm4_oa_powder matches 1.. run particle minecraft:dust{color:[0.459d,0.2d,0.09d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if score @s gm4_oa_glowstone matches 1.. run particle minecraft:dust{color:[0.459d,0.431d,0.055d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if score @s gm4_oa_tears matches 1.. run particle minecraft:dust{color:[0.384d,0.451d,0.459d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if score @s gm4_oa_roses matches 1.. run particle minecraft:dust{color:[0.204d,0.165d,0.259d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if score @s gm4_oa_essence matches 1.. run particle minecraft:dust{color:[0.18d,0.169d,0.31d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if entity @s[tag=gm4_oa_has_orb] run particle minecraft:dust{color:[0.725d,0.729d,0.78d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force
execute if entity @s[tag=gm4_oa_has_shard] run particle minecraft:dust{color:[0.271d,0.149d,0.388d],scale:2} ~ ~0.2 ~ 0.1 0.8 0.1 0.03 6 force

# wither rose consumption
execute if entity @s[tag=gm4_oa_has_orb, tag=gm4_oa_has_shard] run function gm4_orb_of_ankou:soul_forge/wither_roses/steps

# wither rose particle line
execute as @e[type=marker, tag=gm4_oa_wither_particle] at @s run function gm4_orb_of_ankou:soul_forge/wither_roses/particle
