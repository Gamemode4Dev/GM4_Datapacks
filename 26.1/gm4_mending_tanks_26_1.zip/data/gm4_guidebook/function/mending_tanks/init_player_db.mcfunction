execute if entity @s[advancements={gm4_guidebook:mending_tanks/unlock/usage=true}] run function gm4_guidebook:mending_tanks/rewards/unlock/usage
return 1
