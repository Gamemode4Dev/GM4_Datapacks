execute if entity @s[advancements={gm4_guidebook:chairs/unlock/creation=true}] run function gm4_guidebook:chairs/rewards/unlock/creation
return 1
