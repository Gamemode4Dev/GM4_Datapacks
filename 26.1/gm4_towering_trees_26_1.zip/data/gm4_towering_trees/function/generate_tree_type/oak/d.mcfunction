# generates the tree - mega oak
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/oak/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~15 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 64 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~3 ~ run clone ~ ~ ~ ~17 ~12 ~18 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 4446 run return fail

# optional feature
place feature gm4_towering_trees:leaf_litter ~ ~1 ~

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:oak/d ~-8 ~ ~-8
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:oak/d ~9 ~ ~9 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:oak/d ~9 ~ ~-8 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:oak/d ~-8 ~ ~9 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
