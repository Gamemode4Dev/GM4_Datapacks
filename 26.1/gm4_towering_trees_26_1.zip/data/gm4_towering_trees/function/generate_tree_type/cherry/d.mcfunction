# generates the tree - mega cherry
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/cherry/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~18 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 76 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~3 ~ run clone ~ ~ ~ ~28 ~15 ~16 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 7888 run return fail

# optional feature
place feature gm4_towering_trees:pink_petals ~ ~1 ~

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:cherry/d ~-12 ~ ~-8
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:cherry/d ~13 ~ ~9 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:cherry/d ~9 ~ ~-12 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:cherry/d ~-8 ~ ~13 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
