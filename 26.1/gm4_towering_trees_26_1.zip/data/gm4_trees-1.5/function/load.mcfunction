scoreboard objectives add gm4_tree_data dummy
scoreboard objectives add gm4_sap_stage dummy
scoreboard objectives add gm4_sap_growth dummy

schedule function gm4_trees-1.5:tick 1t replace
schedule function gm4_trees-1.5:main 2t replace
execute unless score trees gm4_earliest_version matches ..105001 run scoreboard players set trees gm4_earliest_version 105001


data modify storage gm4:log versions append value {id:"gm4_trees",module:"lib_trees",version:"1.5.X",from:"Towering Trees"}
