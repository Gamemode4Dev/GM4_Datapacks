tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Towering Trees]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Towering Trees",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.towering_trees",fallback:"Adds mega and small tree variants to any sapling that is missing one!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:towering_trees/display/towering_trees
function gm4_guidebook:towering_trees/rewards/unlock/towering_trees
