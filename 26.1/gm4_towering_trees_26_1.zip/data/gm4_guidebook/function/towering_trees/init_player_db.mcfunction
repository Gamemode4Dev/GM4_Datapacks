execute if entity @s[advancements={gm4_guidebook:towering_trees/unlock/towering_trees=true}] run function gm4_guidebook:towering_trees/rewards/unlock/towering_trees
return 1
