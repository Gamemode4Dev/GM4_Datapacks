# process fear cloud skull
# @s = block_display
# at @s
# run from clocks/elite/vorpal_death

# particles
particle dust{color:[0.0d,0.0d,0.0d],scale:1} ^ ^ ^0.0125 0.2666 0.2666 0.2666 0.666 4 normal

scoreboard players add @s gm4_mu_timer 1

# track towards closest player
execute facing entity @p[gamemode=!spectator, gamemode=!creative] eyes positioned ^ ^ ^25 rotated as @s positioned ^ ^ ^25 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ~ ~ ~ ~ ~
tp @s[scores={gm4_mu_timer=..29}] ^ ^ ^0.025
tp @s[scores={gm4_mu_timer=30..60}] ^ ^ ^0.075
tp @s[scores={gm4_mu_timer=61..90}] ^ ^ ^0.125
tp @s[scores={gm4_mu_timer=91..120}] ^ ^ ^0.2
tp @s[scores={gm4_mu_timer=121..140}] ^ ^ ^0.3
tp @s[scores={gm4_mu_timer=141..160}] ^ ^ ^0.45
tp @s[scores={gm4_mu_timer=161..}] ^ ^ ^0.65

# hit players
scoreboard players set $player_hit gm4_mu_data 0
execute positioned ~-0.15 ~-0.15 ~-0.15 as @a[dx=0, dy=0, dz=0, gamemode=!spectator, gamemode=!creative] positioned ~-0.55 ~-0.55 ~-0.55 if entity @s[dx=0, dy=0, dz=0] run function gm4_monsters_unbound:mob/process/elite/vorpal/fear_hit
execute if score $player_hit gm4_mu_data matches 1 run return run kill @s

# timer ran out
execute if score @s gm4_mu_timer matches 240.. run return run kill @s

# keep running if entity is still around
scoreboard players set $keep_tick.elite_death_vorpal gm4_mu_keep_tick 1
