tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Monsters Unbound]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Monsters Unbound",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.monsters_unbound",fallback:"Mobs gain special effects based on their biome.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:monsters_unbound/display/snowy
function gm4_guidebook:monsters_unbound/rewards/unlock/snowy
