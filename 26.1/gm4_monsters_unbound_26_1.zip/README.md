# <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="GM4 Logo" width="32" /> Monsters Unbound by Gamemode 4

Use special weapon and armour modifiers to defend against mobs that grow ever stronger!

<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/gm4_monsters_unbound/images/monsters_unbound.png" alt="Spore Zombies in Lush Caves" height="350"/>   

### Features
- The longer you stay alive the stronger mobs will become.
- Different biomes grant special buffs to mobs that spawn in them, creating bigger Slimes or Spore Zombies that keep regrowing!
- Weaker Phantoms that take damage if they try to fly into water, as they deserve.
- Mobs will drop new Modified armour and weapons. These come with special attributes that allow you to customize your gear!
- Modifiers range from a ramping speed boost to a loyal immortal dog to fight by your side. Or a piece of armour that teleports you randomly, if that's what you like.

A full list of all modifiers to mobs, weapons and armor can be found at the [Wiki](https://wiki.gm4.co/Monsters_Unbound).

### More Info
[<img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_wiki_logo.png" alt="Gamemode 4 Wiki Logo" width="40" align="center"/> **Read the Wiki**](https://wiki.gm4.co/wiki/Monsters_Unbound)

### Credits
- Creator: [Djones](https://bsky.app/profile/thanathor.bsky.social)
- Icon Design: Hozz
- Textures: [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social), rednls

---
## About Gamemode 4 <img src="https://raw.githubusercontent.com/Gamemode4Dev/GM4_Datapacks/master/base/images/gm4_logo.png" alt="Gamemode 4 Logo" width="20"/>
Gamemode 4 is a series of command-powered creations that are designed to change and enhance the survival experience. All of our modules are designed to work together flawlessly, and are balanced for usage in a survival setting. Pick and choose your favorites from our [website](https://gm4.co), or wherever you get datapacks.