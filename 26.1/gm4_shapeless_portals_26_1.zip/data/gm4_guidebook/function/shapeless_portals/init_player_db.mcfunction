execute if entity @s[advancements={gm4_guidebook:shapeless_portals/unlock/description=true}] run function gm4_guidebook:shapeless_portals/rewards/unlock/description
return 1
