tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Shapeless Portals]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Shapeless Portals",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.shapeless_portals",fallback:"Say goodbye to your boring old rectangular portals!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:shapeless_portals/display/description
function gm4_guidebook:shapeless_portals/rewards/unlock/description
