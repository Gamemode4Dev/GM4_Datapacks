execute if entity @s[advancements={gm4_guidebook:pig_tractors/unlock/description=true}] run function gm4_guidebook:pig_tractors/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:pig_tractors/unlock/usage=true}] run function gm4_guidebook:pig_tractors/rewards/unlock/usage
return 1
