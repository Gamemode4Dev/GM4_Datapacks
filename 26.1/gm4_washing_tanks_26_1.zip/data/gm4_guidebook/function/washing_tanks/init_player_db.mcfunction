execute if entity @s[advancements={gm4_guidebook:washing_tanks/unlock/usage=true}] run function gm4_guidebook:washing_tanks/rewards/unlock/usage
return 1
