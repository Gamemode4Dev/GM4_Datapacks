tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Washing Tanks]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Washing Tanks",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.washing_tanks",fallback:"Die! Dye! Remove die from items in a Liquid Tank filled with Water, at the cost of \u2153 of a bucket.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:washing_tanks/display/usage
function gm4_guidebook:washing_tanks/rewards/unlock/usage
