scoreboard objectives add gm4_potion_id dummy
scoreboard objectives add gm4_potion_time dummy
execute unless score potion_tracking gm4_earliest_version matches ..104000 run scoreboard players set potion_tracking gm4_earliest_version 104000


data modify storage gm4:log versions append value {id:"gm4_potion_tracking",module:"lib_potion_tracking",version:"1.4.X",from:"Gamemode 4 Potion Tracking"}
