execute if entity @s[advancements={gm4_guidebook:particles_pack/unlock/description=true}] run function gm4_guidebook:particles_pack/rewards/unlock/description
return 1
