execute if entity @s[advancements={gm4_guidebook:better_armour_stands/unlock/description=true}] run function gm4_guidebook:better_armour_stands/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:better_armour_stands/unlock/codes=true}] run function gm4_guidebook:better_armour_stands/rewards/unlock/codes
return 1
