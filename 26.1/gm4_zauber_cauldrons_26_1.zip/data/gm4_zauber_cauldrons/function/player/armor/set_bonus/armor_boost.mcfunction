# applies a set bonus and displays some particles
# @s = player who's inventory changed and now has full armor_boost armor
# at @s
# run from player/armor/apply_set_bonus

# attribute
attribute @s minecraft:armor modifier add gm4_zauber_cauldrons:armor_boost 1 add_value

# sounds and visuals
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ~0.3 ~0.8 ~0.3 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ~0.3 ~0.8 ~-0.3 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ~-0.3 ~0.8 ~-0.3 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ~-0.3 ~0.8 ~0.3 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ^ ^1.2 ^0.1 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ^ ^1.2 ^-0.1 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ^0.1 ^1.2 ^ 0 0 0 1 1
particle minecraft:entity_effect{color:[0.561d,0.271d,0.929d,1.0d]} ^-0.1 ^1.2 ^ 0 0 0 1 1
playsound minecraft:block.beacon.power_select player @a[distance=..4] ~ ~ ~ 0.2 1.55
