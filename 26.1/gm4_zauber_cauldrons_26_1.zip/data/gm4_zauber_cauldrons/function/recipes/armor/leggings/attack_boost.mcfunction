# @s = heated water zauber cauldron with enchanted prismarine shard and golden leggings inside
# at @s (center of block)
# run from recipe/armor/leggings/select_flavor

# remove ingredients
execute align xyz run kill @e[type=item, dx=0, dy=0, dz=0]

# summon item
# item modifier is generated via beet from templates
summon item ~ ~0.2 ~ {Tags:["gm4_zc_temp_armor_piece"],Item:{id:"minecraft:golden_leggings",count:1}}
execute as @e[type=item, dx=0, dy=0, dz=0, tag=gm4_zc_temp_armor_piece, limit=1] run function gm4_zauber_cauldrons:recipes/armor/init_piece with storage gm4_zauber_cauldrons:temp/cauldron/ingredients items[{count:1,id:"minecraft:golden_leggings"}]
item modify entity @e[type=item, dx=0, dy=0, dz=0, tag=gm4_zc_temp_armor_piece, limit=1] contents gm4_zauber_cauldrons:armor/leggings/attack_boost
tag @e[type=item, dx=0, dy=0, dz=0] remove gm4_zc_temp_armor_piece

# set flag
scoreboard players set $recipe_success gm4_zc_data 1
