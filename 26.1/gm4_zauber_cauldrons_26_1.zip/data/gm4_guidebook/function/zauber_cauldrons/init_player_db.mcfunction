execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/creation=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/creation
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/recipes=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/recipes
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/potions=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/potions
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/enchanted_shard=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/enchanted_shard
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/armor=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/armor
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/crystals=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/crystals
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/luck=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/luck
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/extra_ingredients=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/extra_ingredients
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/magic_in_a_bottle=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/magic_in_a_bottle
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/magicol_usage=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/magicol_usage
execute if entity @s[advancements={gm4_guidebook:zauber_cauldrons/unlock/wormholes=true}] run function gm4_guidebook:zauber_cauldrons/rewards/unlock/wormholes
return 1
