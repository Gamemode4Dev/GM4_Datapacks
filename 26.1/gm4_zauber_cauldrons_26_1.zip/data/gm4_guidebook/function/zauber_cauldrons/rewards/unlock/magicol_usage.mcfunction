data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "zauber_cauldrons"
data modify storage gm4_guidebook:temp unlocking.target_page set value 25
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 30
data modify storage gm4_guidebook:temp unlocking.source_page set value "magicol_usage_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 26
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 31
data modify storage gm4_guidebook:temp unlocking.source_page set value "magicol_usage_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 27
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 32
data modify storage gm4_guidebook:temp unlocking.source_page set value "magicol_usage_2"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 28
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 33
data modify storage gm4_guidebook:temp unlocking.source_page set value "magicol_usage_3"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
