data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "zauber_cauldrons"
data modify storage gm4_guidebook:temp unlocking.target_page set value 19
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 24
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 20
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 25
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 21
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 26
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_2"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 22
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 27
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_3"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 23
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 28
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_4"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 24
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 29
data modify storage gm4_guidebook:temp unlocking.source_page set value "magic_in_a_bottle_5"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
