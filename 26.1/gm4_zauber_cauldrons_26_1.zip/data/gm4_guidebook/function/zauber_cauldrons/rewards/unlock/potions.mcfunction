data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "zauber_cauldrons"
data modify storage gm4_guidebook:temp unlocking.target_page set value 3
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 8
data modify storage gm4_guidebook:temp unlocking.source_page set value "potions_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 4
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 9
data modify storage gm4_guidebook:temp unlocking.source_page set value "potions_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 5
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 10
data modify storage gm4_guidebook:temp unlocking.source_page set value "potions_2"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 6
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 11
data modify storage gm4_guidebook:temp unlocking.source_page set value "potions_3"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
