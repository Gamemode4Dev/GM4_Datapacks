execute if entity @s[advancements={gm4_guidebook:ender_hoppers/unlock/crafting=true}] run function gm4_guidebook:ender_hoppers/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:ender_hoppers/unlock/usage=true}] run function gm4_guidebook:ender_hoppers/rewards/unlock/usage
return 1
