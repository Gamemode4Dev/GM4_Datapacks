# destroys the disassembler
# @s = disassembler marker
# located at @s
# run from gm4_disassemblers:machine/verify_destroy

# kill legacy armor stand - TODO: remove this when we no longer support the upgrade path
execute positioned ~ ~-0.4 ~ run kill @e[type=armor_stand, tag=gm4_disassembler_stand, limit=1, distance=..0.01]
# kill entities related to machine block
kill @e[type=item_display, tag=gm4_disassembler_display, limit=1, distance=..0.01]
execute store result score $dropped_item gm4_machine_data run kill @e[type=item, distance=..1, nbt={Age:0s,Item:{id:"minecraft:dropper",count:1,components:{}}}, limit=1, sort=nearest]
kill @s

# drop item (unless broken in creative mode)
particle minecraft:block{block_state:"minecraft:tnt"} ~ ~ ~ 0.1 0.25 0.1 0.05 30 normal @a
execute if score $dropped_item gm4_machine_data matches 1 run loot spawn ~ ~ ~ loot gm4_disassemblers:items/disassembler
