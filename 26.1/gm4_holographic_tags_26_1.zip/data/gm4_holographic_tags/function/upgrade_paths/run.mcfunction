execute if score holographic_tags gm4_earliest_version matches ..104999 run function gm4_holographic_tags:upgrade_paths/1.5
execute if score holographic_tags gm4_earliest_version matches ..104999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
