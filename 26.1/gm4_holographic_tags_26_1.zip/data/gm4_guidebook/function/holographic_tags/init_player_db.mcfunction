execute if entity @s[advancements={gm4_guidebook:holographic_tags/unlock/creation=true}] run function gm4_guidebook:holographic_tags/rewards/unlock/creation
execute if entity @s[advancements={gm4_guidebook:holographic_tags/unlock/colors=true}] run function gm4_guidebook:holographic_tags/rewards/unlock/colors
return 1
