tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Holographic Tags]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Holographic Tags",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.holographic_tags",fallback:"Set up floating messages with a simple name tag!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:holographic_tags/display/creation
function gm4_guidebook:holographic_tags/rewards/unlock/creation
