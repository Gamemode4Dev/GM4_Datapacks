execute if entity @s[advancements={gm4_guidebook:end_fishing/unlock/void_fishing=true}] run function gm4_guidebook:end_fishing/rewards/unlock/void_fishing
execute if entity @s[advancements={gm4_guidebook:end_fishing/unlock/end_phantoms=true}] run function gm4_guidebook:end_fishing/rewards/unlock/end_phantoms
return 1
