# Credits

## Creator
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
