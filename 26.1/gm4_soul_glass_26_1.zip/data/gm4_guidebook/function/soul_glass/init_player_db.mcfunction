execute if entity @s[advancements={gm4_guidebook:soul_glass/unlock/description=true}] run function gm4_guidebook:soul_glass/rewards/unlock/description
execute if entity @s[advancements={gm4_guidebook:soul_glass/unlock/usage=true}] run function gm4_guidebook:soul_glass/rewards/unlock/usage
return 1
