tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Cooler Caves]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Cooler Caves",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.cooler_caves",fallback:"A custom terrain expansion pack that makes biome specific caves",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:cooler_caves/display/cave_changes
function gm4_guidebook:cooler_caves/rewards/unlock/cave_changes
