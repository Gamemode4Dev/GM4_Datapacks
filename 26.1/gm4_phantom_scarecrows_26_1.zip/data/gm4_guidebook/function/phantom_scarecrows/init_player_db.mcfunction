execute if entity @s[advancements={gm4_guidebook:phantom_scarecrows/unlock/creation=true}] run function gm4_guidebook:phantom_scarecrows/rewards/unlock/creation
execute if entity @s[advancements={gm4_guidebook:phantom_scarecrows/unlock/usage=true}] run function gm4_guidebook:phantom_scarecrows/rewards/unlock/usage
return 1
