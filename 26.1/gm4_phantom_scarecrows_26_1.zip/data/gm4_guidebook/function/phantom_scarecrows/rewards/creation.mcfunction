tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Phantom Scarecrows]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Phantom Scarecrows",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.phantom_scarecrows",fallback:"Set up Scarecrows that shoot homing rockets at Phantoms!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:phantom_scarecrows/display/creation
function gm4_guidebook:phantom_scarecrows/rewards/unlock/creation
