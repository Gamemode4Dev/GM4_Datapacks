# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Inspired by
- [Chopper2112](https://twitter.com/TheChopper2112)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
