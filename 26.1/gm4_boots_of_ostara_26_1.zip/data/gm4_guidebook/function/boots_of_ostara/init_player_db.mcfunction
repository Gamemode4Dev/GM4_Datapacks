execute unless score gm4_desire_lines load.status matches 1.. if entity @s[advancements={gm4_guidebook:boots_of_ostara/unlock/crafting=true}] run function gm4_guidebook:boots_of_ostara/rewards/unlock/crafting
execute if score gm4_desire_lines load.status matches 1.. if entity @s[advancements={gm4_guidebook:boots_of_ostara/unlock/crafting-desire_lines=true}] run function gm4_guidebook:boots_of_ostara/rewards/unlock/crafting-desire_lines
execute if entity @s[advancements={gm4_guidebook:boots_of_ostara/unlock/usage=true}] run function gm4_guidebook:boots_of_ostara/rewards/unlock/usage
return 1
