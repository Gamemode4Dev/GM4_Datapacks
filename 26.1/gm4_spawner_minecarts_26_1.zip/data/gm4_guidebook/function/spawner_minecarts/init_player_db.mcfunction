execute if entity @s[advancements={gm4_guidebook:spawner_minecarts/unlock/pick_up=true}] run function gm4_guidebook:spawner_minecarts/rewards/unlock/pick_up
return 1
