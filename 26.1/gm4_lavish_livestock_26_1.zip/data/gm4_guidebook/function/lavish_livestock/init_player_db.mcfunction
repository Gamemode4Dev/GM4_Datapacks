execute if entity @s[advancements={gm4_guidebook:lavish_livestock/unlock/display=true}] run function gm4_guidebook:lavish_livestock/rewards/unlock/display
return 1
