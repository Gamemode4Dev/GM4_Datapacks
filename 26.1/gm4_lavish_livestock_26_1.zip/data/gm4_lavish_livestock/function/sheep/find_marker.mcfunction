# Called once the parent has given birth and initiates breeding sites to look for babies.
# @s = undefined
# at undefined
# scheduled from gm4_lavish_livestock:sheep/revoke_advancement

execute as @e[type=marker, tag=gm4_lavish_livestock_breeding_site, tag=gm4_lavish_livestock_sheep] at @s run function gm4_lavish_livestock:sheep/find_baby
