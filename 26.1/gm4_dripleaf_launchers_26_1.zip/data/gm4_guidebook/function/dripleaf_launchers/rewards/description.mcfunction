tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Dripleaf Launchers]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Dripleaf Launchers",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.dripleaf_launchers",fallback:"Start your own Dripleaf Space Program!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:dripleaf_launchers/display/description
function gm4_guidebook:dripleaf_launchers/rewards/unlock/description
