execute if entity @s[advancements={gm4_guidebook:icy_strays/unlock/description=true}] run function gm4_guidebook:icy_strays/rewards/unlock/description
return 1
