execute if entity @s[advancements={gm4_guidebook:illusioner_nights/unlock/description=true}] run function gm4_guidebook:illusioner_nights/rewards/unlock/description
return 1
