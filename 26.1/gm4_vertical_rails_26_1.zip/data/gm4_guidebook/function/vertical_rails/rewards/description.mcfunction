tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Vertical Rails]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Vertical Rails",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.vertical_rails",fallback:"Use ladders as vertical Minecart tracks.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:vertical_rails/display/description
function gm4_guidebook:vertical_rails/rewards/unlock/description
