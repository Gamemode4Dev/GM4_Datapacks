execute if entity @s[advancements={gm4_guidebook:bookshelf_inspector/unlock/display=true}] run function gm4_guidebook:bookshelf_inspector/rewards/unlock/display
return 1
