execute if entity @s[advancements={gm4_guidebook:metallurgy/unlock/lump_obtaining=true}] run function gm4_guidebook:metallurgy/rewards/unlock/lump_obtaining
execute if entity @s[advancements={gm4_guidebook:metallurgy/unlock/casting=true}] run function gm4_guidebook:metallurgy/rewards/unlock/casting
execute if entity @s[advancements={gm4_guidebook:metallurgy/unlock/shamirs=true}] run function gm4_guidebook:metallurgy/rewards/unlock/shamirs
return 1
