# mark this gm4_horse as grazing
# @s = gm4_horse
# at @s
# run from main

schedule function gm4_horsemanship:horse_processing/graze/tick 1
tag @s add gm4_horse.grazing
