tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Lightning in a Bottle]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Lightning in a Bottle",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.lightning_in_a_bottle",fallback:"Bottle and harness the power of lightning using Brewing Stands! Lightning in a Bottle comes in splash and lingering variants, too.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:lightning_in_a_bottle/display/usage
advancement grant @s only gm4_guidebook:lightning_in_a_bottle/unlock/description
advancement grant @s only gm4_guidebook:lightning_in_a_bottle/unlock/obtaining
function gm4_guidebook:lightning_in_a_bottle/rewards/unlock/usage
