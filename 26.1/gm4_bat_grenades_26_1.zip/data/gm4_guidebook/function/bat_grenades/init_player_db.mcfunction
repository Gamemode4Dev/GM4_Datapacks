execute if entity @s[advancements={gm4_guidebook:bat_grenades/unlock/bat_explosions=true}] run function gm4_guidebook:bat_grenades/rewards/unlock/bat_explosions
return 1
