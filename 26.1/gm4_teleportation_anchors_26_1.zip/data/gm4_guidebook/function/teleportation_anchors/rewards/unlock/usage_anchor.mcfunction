data modify storage gm4_guidebook:temp unlocking.uuid set from entity @s UUID
data modify storage gm4_guidebook:temp unlocking.name set value "teleportation_anchors"
data modify storage gm4_guidebook:temp unlocking.target_page set value 7
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 12
data modify storage gm4_guidebook:temp unlocking.source_page set value "usage_anchor_0"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 8
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 13
data modify storage gm4_guidebook:temp unlocking.source_page set value "usage_anchor_1"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 9
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 14
data modify storage gm4_guidebook:temp unlocking.source_page set value "usage_anchor_2"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data modify storage gm4_guidebook:temp unlocking.target_page set value 10
data modify storage gm4_guidebook:temp unlocking.lectern_target_page set value 15
data modify storage gm4_guidebook:temp unlocking.source_page set value "usage_anchor_3"
function gm4_guidebook:player_db/update with storage gm4_guidebook:temp unlocking
data remove storage gm4_guidebook:temp unlocking
