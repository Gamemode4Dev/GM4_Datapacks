# @s = gm4_teleportation_jammer_stand armor stand
# at center of block
# run from upgrade_paths/1.7

summon minecraft:item_display ~ ~ ~ {CustomName:"gm4_teleportation_jammer_display",Tags:["gm4_no_edit","gm4_teleportation_jammer_display","gm4_machine_display","smithed.entity","smithed.strict"],item:{id:"purpur_pillar",count:1,components:{"minecraft:custom_model_data":{strings:["gm4_teleportation_anchors:block/teleportation_jammer"]}}},item_display:"head",brightness:{sky:15,block:15},Rotation:[0.0f,0.0f],transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.501f,0.0f],scale:[0.438d,0.438d,0.438d]}}









# entity version
scoreboard players set @e[type=item_display, tag=gm4_teleportation_jammer_display, distance=..0.01, limit=1] gm4_entity_version 2
scoreboard players set @e[type=marker, tag=gm4_teleportation_jammer, distance=..0.01, limit=1] gm4_entity_version 2

kill @s
