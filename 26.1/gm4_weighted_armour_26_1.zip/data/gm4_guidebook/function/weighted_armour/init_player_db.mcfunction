execute if entity @s[advancements={gm4_guidebook:weighted_armour/unlock/description=true}] run function gm4_guidebook:weighted_armour/rewards/unlock/description
execute unless score gm4_metallurgy load.status matches 1.. if entity @s[advancements={gm4_guidebook:weighted_armour/unlock/weight=true}] run function gm4_guidebook:weighted_armour/rewards/unlock/weight
execute if score gm4_metallurgy load.status matches 1.. if entity @s[advancements={gm4_guidebook:weighted_armour/unlock/weight_and_helious=true}] run function gm4_guidebook:weighted_armour/rewards/unlock/weight_and_helious
return 1
