tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Helious Shamir]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Helious Shamir",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.helious_shamir",fallback:"Perfect for UHCs, this module forces you to balance protection with speed.",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:helious_shamir/display/usage
function gm4_guidebook:helious_shamir/rewards/unlock/usage
