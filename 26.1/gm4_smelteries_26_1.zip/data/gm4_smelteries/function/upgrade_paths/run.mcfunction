execute if score smelteries gm4_earliest_version matches ..108999 run function gm4_smelteries:upgrade_paths/1.9
execute if score smelteries gm4_earliest_version matches ..108999 run scoreboard players add $active_upgrade_paths gm4_data 1
tag @s remove gm4_running_upgrade_path
