execute if entity @s[advancements={gm4_guidebook:smelteries/unlock/crafting=true}] run function gm4_guidebook:smelteries/rewards/unlock/crafting
execute if entity @s[advancements={gm4_guidebook:smelteries/unlock/usage=true}] run function gm4_guidebook:smelteries/rewards/unlock/usage
return 1
