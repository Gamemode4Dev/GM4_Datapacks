# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated By
- [dvitski](https://bsky.app/profile/dvitski.cc)
- [Kroppeb](https://tech.lgbt/@Kroppeb)
- [Misode](https://bsky.app/profile/misode.dev)
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [BPR](https://bsky.app/profile/bpr02.com)
- [runcows](https://bsky.app/profile/runcows.bsky.social)

## Textures By
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- Hozz
