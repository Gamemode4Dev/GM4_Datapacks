execute if score gm4_player_death load.status matches 1 if score gm4_player_death_minor load.status matches 5 run function gm4_player_death-1.5:load
