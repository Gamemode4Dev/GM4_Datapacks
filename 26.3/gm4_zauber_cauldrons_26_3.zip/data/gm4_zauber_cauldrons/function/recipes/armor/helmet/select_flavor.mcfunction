# @s = heated water zauber cauldron with enchanted prismarine shard and golden helmet inside
# at @s (center of block)
# run from recipe/armor/select_piece

# generated with the help of bolt

execute unless score $recipe_success gm4_zc_data matches 1.. if data storage gm4_zauber_cauldrons:temp/cauldron/ingredients items[{count:1,components:{"minecraft:custom_data":{gm4_zauber_cauldrons:{item:"minecraft:turtle_helmet"}}}}] run function gm4_zauber_cauldrons:recipes/armor/helmet/armor_boost
execute unless score $recipe_success gm4_zc_data matches 1.. if data storage gm4_zauber_cauldrons:temp/cauldron/ingredients items[{count:1,components:{"minecraft:custom_data":{gm4_zauber_cauldrons:{item:"minecraft:blaze_powder"}}}}] run function gm4_zauber_cauldrons:recipes/armor/helmet/attack_boost
execute unless score $recipe_success gm4_zc_data matches 1.. if data storage gm4_zauber_cauldrons:temp/cauldron/ingredients items[{count:1,components:{"minecraft:custom_data":{gm4_zauber_cauldrons:{item:"minecraft:glistering_melon_slice"}}}}] run function gm4_zauber_cauldrons:recipes/armor/helmet/health_boost
execute unless score $recipe_success gm4_zc_data matches 1.. if data storage gm4_zauber_cauldrons:temp/cauldron/ingredients items[{count:1,components:{"minecraft:custom_data":{gm4_zauber_cauldrons:{item:"minecraft:sugar"}}}}] run function gm4_zauber_cauldrons:recipes/armor/helmet/speed_boost
