execute if score gm4_player_motion load.status matches 1 if score gm4_player_motion_minor load.status matches 2 run function gm4_player_motion-1.2:load
execute unless score gm4_player_motion load.status matches 1 run schedule clear gm4_player_motion-1.2:internal/technical/tick
execute unless score gm4_player_motion_minor load.status matches 2 run schedule clear gm4_player_motion-1.2:internal/technical/tick
