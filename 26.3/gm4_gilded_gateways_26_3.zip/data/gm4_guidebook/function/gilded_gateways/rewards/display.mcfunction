tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Gilded Gateways]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Gilded Gateways",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.gilded_gateways",fallback:"Tired of boring bedrock end gateways? Bring back the magic with custom gateways!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:gilded_gateways/display/display
function gm4_guidebook:gilded_gateways/rewards/unlock/display
