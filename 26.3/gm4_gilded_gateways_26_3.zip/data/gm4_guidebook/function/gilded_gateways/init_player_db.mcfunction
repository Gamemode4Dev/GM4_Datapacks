execute if entity @s[advancements={gm4_guidebook:gilded_gateways/unlock/display=true}] run function gm4_guidebook:gilded_gateways/rewards/unlock/display
return 1
