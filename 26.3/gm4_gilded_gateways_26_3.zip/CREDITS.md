# Credits

## Creators
- [runcows](https://bsky.app/profile/runcows.bsky.social)
- [Dinoguin_Jess](https://github.com/Dinoguin-Jess)

## Icon Design
- [runcows](https://bsky.app/profile/runcows.bsky.social)
