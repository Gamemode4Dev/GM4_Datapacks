execute if score gm4_player_motion load.status matches 1 if score gm4_player_motion_minor load.status matches 3 run function gm4_player_motion-1.3:api/launch_global_xyz
