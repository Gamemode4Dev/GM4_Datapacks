execute if score gm4_player_motion load.status matches 1 unless score gm4_player_motion_minor load.status matches 3.. run scoreboard players set gm4_player_motion_minor load.status 3

execute if score gm4_forceload load.status matches 1 if score gm4_forceload_minor load.status matches 7.. unless score gm4_player_motion load.status matches 1.. run scoreboard players set gm4_player_motion_minor load.status 3
execute if score gm4_forceload load.status matches 1 if score gm4_forceload_minor load.status matches 7.. unless score gm4_player_motion load.status matches 1.. run scoreboard players set gm4_player_motion load.status 1
