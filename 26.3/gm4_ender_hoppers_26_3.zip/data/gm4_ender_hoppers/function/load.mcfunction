execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. if score gm4_machines load.status matches 1 if score gm4_machines_minor load.status matches 6.. run scoreboard players set gm4_ender_hoppers load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. if score gm4_machines load.status matches 1 if score gm4_machines_minor load.status matches 6.. run scoreboard players set gm4_ender_hoppers_minor load.status 10
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 10.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute unless score gm4_machines load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"lib_machines",require_id:"gm4_machines"}
execute if score gm4_machines load.status matches 1.. unless score gm4_machines load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"lib_machines",require_id:"gm4_machines",require_ver:"1.6.0"}
execute if score gm4_machines load.status matches 1 unless score gm4_machines_minor load.status matches 6.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Ender Hoppers",id:"gm4_ender_hoppers",require:"lib_machines",require_id:"gm4_machines",require_ver:"1.6.0"}
execute unless score gm4_ender_hoppers load.status matches 1.. run scoreboard players set gm4_ender_hoppers load.status -1

execute if score gm4_ender_hoppers load.status matches 1 run function gm4_ender_hoppers:init
execute unless score gm4_ender_hoppers load.status matches 1 run schedule clear gm4_ender_hoppers:main
