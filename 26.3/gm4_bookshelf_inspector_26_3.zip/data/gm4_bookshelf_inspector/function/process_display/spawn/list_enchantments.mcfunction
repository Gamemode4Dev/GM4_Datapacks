# create a list of all the enchantments
# @s = text display
# at chiseled bookshelf, selected book slot
# run from process_display/spawn/decide_name

# create array of all enchantments with levels
scoreboard players set $enchantments_max gm4_bookshelf_inspector_data 4
data modify storage gm4_bookshelf_inspector:temp levels set from storage gm4_bookshelf_inspector:temp book_data.components."minecraft:stored_enchantments"
function gm4_bookshelf_inspector:process_display/spawn/components_to_list
data modify storage gm4_bookshelf_inspector:temp enchantment_list set value []
function gm4_bookshelf_inspector:process_display/spawn/process_enchantments

# add to the text
data modify storage gm4_bookshelf_inspector:temp text append value {nbt:"enchantment_list[]",storage:"gm4_bookshelf_inspector:temp",separator:"\n",interpret:true,color:"gray"}

# cleanup
data remove storage gm4_bookshelf_inspector:temp enchantments
data remove storage gm4_bookshelf_inspector:temp levels
