scoreboard objectives add gm4_lore dummy
execute unless score lore gm4_earliest_version matches ..105000 run scoreboard players set lore gm4_earliest_version 105000


data modify storage gm4:log versions append value {id:"gm4_lore",module:"lib_lore",version:"1.5.X",from:"Gamemode 4 Lore"}
