scoreboard objectives add gm4_dimension dummy
gamerule command_block_output false

execute store success score $initialized gm4_dimension if block 29999998 1 7133 birch_wall_sign
execute if score $initialized gm4_dimension matches 0 positioned ~ 0 ~ summon marker run function gm4_forceload-1.7:init_ow_chunk
execute unless score forceload gm4_earliest_version matches ..107001 run scoreboard players set forceload gm4_earliest_version 107001


data modify storage gm4:log versions append value {id:"gm4_forceload",module:"lib_forceload",version:"1.7.X",from:"Smelteries"}
