execute if score gm4_machines load.status matches 1 if score gm4_machines_minor load.status matches 6 run function gm4_machines-1.6:load
execute unless score gm4_machines load.status matches 1 run schedule clear gm4_machines-1.6:main
execute unless score gm4_machines_minor load.status matches 6 run schedule clear gm4_machines-1.6:main
