execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. run scoreboard players set gm4_rope_ladders load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. run scoreboard players set gm4_rope_ladders_minor load.status 7
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Rope Ladders",id:"gm4_rope_ladders",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Rope Ladders",id:"gm4_rope_ladders",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 10.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Rope Ladders",id:"gm4_rope_ladders",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute unless score gm4_rope_ladders load.status matches 1.. run scoreboard players set gm4_rope_ladders load.status -1

execute if score gm4_rope_ladders load.status matches 1 run function gm4_rope_ladders:init
execute unless score gm4_rope_ladders load.status matches 1 run schedule clear gm4_rope_ladders:main
execute unless score gm4_rope_ladders load.status matches 1 run schedule clear gm4_rope_ladders:tick
