execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 10.. run scoreboard players set gm4_minor load.status 10

execute unless score gm4 load.status matches 1.. run scoreboard players set gm4_minor load.status 10
execute unless score gm4 load.status matches 1.. run scoreboard players set gm4 load.status 1
