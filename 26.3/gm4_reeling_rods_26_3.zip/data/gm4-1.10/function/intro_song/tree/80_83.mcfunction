execute if entity @s[scores={gm4_intro_song=6400..6600}] run function gm4-1.10:intro_song/tree/80_81
