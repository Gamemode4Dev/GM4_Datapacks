execute if score gm4_hooked_entity load.status matches 1 if score gm4_hooked_entity_minor load.status matches 1 run function gm4_hooked_entity-1.1:load
execute unless score gm4_hooked_entity load.status matches 1 run schedule clear gm4_hooked_entity-1.1:tick
execute unless score gm4_hooked_entity_minor load.status matches 1 run schedule clear gm4_hooked_entity-1.1:tick
