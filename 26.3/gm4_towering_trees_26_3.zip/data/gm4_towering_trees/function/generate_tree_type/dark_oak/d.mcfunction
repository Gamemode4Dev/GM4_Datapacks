# generates the tree - mega dark_oak
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/dark_oak/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~ ~8 ~ ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 9 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~6 ~ run clone ~ ~ ~ ~7 ~2 ~6 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 168 run return fail

# optional feature
#

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:dark_oak/d ~-4 ~ ~-3
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:dark_oak/d ~4 ~ ~3 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:dark_oak/d ~3 ~ ~-4 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:dark_oak/d ~-3 ~ ~4 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
