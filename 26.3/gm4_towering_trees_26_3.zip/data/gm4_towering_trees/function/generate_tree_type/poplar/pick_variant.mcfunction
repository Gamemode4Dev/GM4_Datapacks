# generates the tree - mega 
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_mega_tree

execute store result score $tree_variant gm4_towering_trees_data run random value 1..72

execute if score $tree_variant gm4_towering_trees_data matches 1 run function gm4_towering_trees:generate_tree_type/poplar/a1
execute if score $tree_variant gm4_towering_trees_data matches 2 run function gm4_towering_trees:generate_tree_type/poplar/a1m
execute if score $tree_variant gm4_towering_trees_data matches 3 run function gm4_towering_trees:generate_tree_type/poplar/a2
execute if score $tree_variant gm4_towering_trees_data matches 4 run function gm4_towering_trees:generate_tree_type/poplar/a2m
execute if score $tree_variant gm4_towering_trees_data matches 5 run function gm4_towering_trees:generate_tree_type/poplar/a3
execute if score $tree_variant gm4_towering_trees_data matches 6 run function gm4_towering_trees:generate_tree_type/poplar/a3m
execute if score $tree_variant gm4_towering_trees_data matches 7 run function gm4_towering_trees:generate_tree_type/poplar/b1
execute if score $tree_variant gm4_towering_trees_data matches 8 run function gm4_towering_trees:generate_tree_type/poplar/b1m
execute if score $tree_variant gm4_towering_trees_data matches 9 run function gm4_towering_trees:generate_tree_type/poplar/b2
execute if score $tree_variant gm4_towering_trees_data matches 10 run function gm4_towering_trees:generate_tree_type/poplar/b2m
execute if score $tree_variant gm4_towering_trees_data matches 11 run function gm4_towering_trees:generate_tree_type/poplar/b3
execute if score $tree_variant gm4_towering_trees_data matches 12 run function gm4_towering_trees:generate_tree_type/poplar/b3m
execute if score $tree_variant gm4_towering_trees_data matches 13 run function gm4_towering_trees:generate_tree_type/poplar/c1
execute if score $tree_variant gm4_towering_trees_data matches 14 run function gm4_towering_trees:generate_tree_type/poplar/c1m
execute if score $tree_variant gm4_towering_trees_data matches 15 run function gm4_towering_trees:generate_tree_type/poplar/c2
execute if score $tree_variant gm4_towering_trees_data matches 16 run function gm4_towering_trees:generate_tree_type/poplar/c2m
execute if score $tree_variant gm4_towering_trees_data matches 17 run function gm4_towering_trees:generate_tree_type/poplar/c3
execute if score $tree_variant gm4_towering_trees_data matches 18 run function gm4_towering_trees:generate_tree_type/poplar/c3m
execute if score $tree_variant gm4_towering_trees_data matches 19 run function gm4_towering_trees:generate_tree_type/poplar/d1
execute if score $tree_variant gm4_towering_trees_data matches 20 run function gm4_towering_trees:generate_tree_type/poplar/d1m
execute if score $tree_variant gm4_towering_trees_data matches 21 run function gm4_towering_trees:generate_tree_type/poplar/d2
execute if score $tree_variant gm4_towering_trees_data matches 22 run function gm4_towering_trees:generate_tree_type/poplar/d2m
execute if score $tree_variant gm4_towering_trees_data matches 23 run function gm4_towering_trees:generate_tree_type/poplar/d3
execute if score $tree_variant gm4_towering_trees_data matches 24 run function gm4_towering_trees:generate_tree_type/poplar/d3m
execute if score $tree_variant gm4_towering_trees_data matches 25 run function gm4_towering_trees:generate_tree_type/poplar/e1
execute if score $tree_variant gm4_towering_trees_data matches 26 run function gm4_towering_trees:generate_tree_type/poplar/e1m
execute if score $tree_variant gm4_towering_trees_data matches 27 run function gm4_towering_trees:generate_tree_type/poplar/e2
execute if score $tree_variant gm4_towering_trees_data matches 28 run function gm4_towering_trees:generate_tree_type/poplar/e2m
execute if score $tree_variant gm4_towering_trees_data matches 29 run function gm4_towering_trees:generate_tree_type/poplar/e3
execute if score $tree_variant gm4_towering_trees_data matches 30 run function gm4_towering_trees:generate_tree_type/poplar/e3m
execute if score $tree_variant gm4_towering_trees_data matches 31 run function gm4_towering_trees:generate_tree_type/poplar/f1
execute if score $tree_variant gm4_towering_trees_data matches 32 run function gm4_towering_trees:generate_tree_type/poplar/f1m
execute if score $tree_variant gm4_towering_trees_data matches 33 run function gm4_towering_trees:generate_tree_type/poplar/f2
execute if score $tree_variant gm4_towering_trees_data matches 34 run function gm4_towering_trees:generate_tree_type/poplar/f2m
execute if score $tree_variant gm4_towering_trees_data matches 35 run function gm4_towering_trees:generate_tree_type/poplar/f3
execute if score $tree_variant gm4_towering_trees_data matches 36 run function gm4_towering_trees:generate_tree_type/poplar/f3m
execute if score $tree_variant gm4_towering_trees_data matches 37 run function gm4_towering_trees:generate_tree_type/poplar/g1
execute if score $tree_variant gm4_towering_trees_data matches 38 run function gm4_towering_trees:generate_tree_type/poplar/g1m
execute if score $tree_variant gm4_towering_trees_data matches 39 run function gm4_towering_trees:generate_tree_type/poplar/g2
execute if score $tree_variant gm4_towering_trees_data matches 40 run function gm4_towering_trees:generate_tree_type/poplar/g2m
execute if score $tree_variant gm4_towering_trees_data matches 41 run function gm4_towering_trees:generate_tree_type/poplar/g3
execute if score $tree_variant gm4_towering_trees_data matches 42 run function gm4_towering_trees:generate_tree_type/poplar/g3m
execute if score $tree_variant gm4_towering_trees_data matches 43 run function gm4_towering_trees:generate_tree_type/poplar/h1
execute if score $tree_variant gm4_towering_trees_data matches 44 run function gm4_towering_trees:generate_tree_type/poplar/h1m
execute if score $tree_variant gm4_towering_trees_data matches 45 run function gm4_towering_trees:generate_tree_type/poplar/h2
execute if score $tree_variant gm4_towering_trees_data matches 46 run function gm4_towering_trees:generate_tree_type/poplar/h2m
execute if score $tree_variant gm4_towering_trees_data matches 47 run function gm4_towering_trees:generate_tree_type/poplar/h3
execute if score $tree_variant gm4_towering_trees_data matches 48 run function gm4_towering_trees:generate_tree_type/poplar/h3m
execute if score $tree_variant gm4_towering_trees_data matches 49 run function gm4_towering_trees:generate_tree_type/poplar/i1
execute if score $tree_variant gm4_towering_trees_data matches 50 run function gm4_towering_trees:generate_tree_type/poplar/i1m
execute if score $tree_variant gm4_towering_trees_data matches 51 run function gm4_towering_trees:generate_tree_type/poplar/i2
execute if score $tree_variant gm4_towering_trees_data matches 52 run function gm4_towering_trees:generate_tree_type/poplar/i2m
execute if score $tree_variant gm4_towering_trees_data matches 53 run function gm4_towering_trees:generate_tree_type/poplar/i3
execute if score $tree_variant gm4_towering_trees_data matches 54 run function gm4_towering_trees:generate_tree_type/poplar/i3m
execute if score $tree_variant gm4_towering_trees_data matches 55 run function gm4_towering_trees:generate_tree_type/poplar/j1
execute if score $tree_variant gm4_towering_trees_data matches 56 run function gm4_towering_trees:generate_tree_type/poplar/j1m
execute if score $tree_variant gm4_towering_trees_data matches 57 run function gm4_towering_trees:generate_tree_type/poplar/j2
execute if score $tree_variant gm4_towering_trees_data matches 58 run function gm4_towering_trees:generate_tree_type/poplar/j2m
execute if score $tree_variant gm4_towering_trees_data matches 59 run function gm4_towering_trees:generate_tree_type/poplar/j3
execute if score $tree_variant gm4_towering_trees_data matches 60 run function gm4_towering_trees:generate_tree_type/poplar/j3m
execute if score $tree_variant gm4_towering_trees_data matches 61 run function gm4_towering_trees:generate_tree_type/poplar/k1
execute if score $tree_variant gm4_towering_trees_data matches 62 run function gm4_towering_trees:generate_tree_type/poplar/k1m
execute if score $tree_variant gm4_towering_trees_data matches 63 run function gm4_towering_trees:generate_tree_type/poplar/k2
execute if score $tree_variant gm4_towering_trees_data matches 64 run function gm4_towering_trees:generate_tree_type/poplar/k2m
execute if score $tree_variant gm4_towering_trees_data matches 65 run function gm4_towering_trees:generate_tree_type/poplar/k3
execute if score $tree_variant gm4_towering_trees_data matches 66 run function gm4_towering_trees:generate_tree_type/poplar/k3m
execute if score $tree_variant gm4_towering_trees_data matches 67 run function gm4_towering_trees:generate_tree_type/poplar/l1
execute if score $tree_variant gm4_towering_trees_data matches 68 run function gm4_towering_trees:generate_tree_type/poplar/l1m
execute if score $tree_variant gm4_towering_trees_data matches 69 run function gm4_towering_trees:generate_tree_type/poplar/l2
execute if score $tree_variant gm4_towering_trees_data matches 70 run function gm4_towering_trees:generate_tree_type/poplar/l2m
execute if score $tree_variant gm4_towering_trees_data matches 71 run function gm4_towering_trees:generate_tree_type/poplar/l3
execute if score $tree_variant gm4_towering_trees_data matches 72 run function gm4_towering_trees:generate_tree_type/poplar/l3m


execute if score $tree_placed gm4_towering_trees_data matches 1 run fill ~ ~-1 ~ ~1 ~-1 ~1 dirt replace grass_block
