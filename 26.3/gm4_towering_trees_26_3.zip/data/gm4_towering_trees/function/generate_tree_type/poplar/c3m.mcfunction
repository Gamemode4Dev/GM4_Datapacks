# generates the tree - mega poplar
# @s = sapling marker
# located at @s (offset to be at the negative corner of the 2x2)
# run from generate_tree_type/poplar/pick_variant

# check trunk
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~ ~ run clone ~ ~ ~ ~1 ~27 ~1 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 112 run return fail

# check box 2
execute store result score $blocks_moved gm4_towering_trees_data positioned ~ ~4 ~ run clone ~ ~ ~ ~10 ~23 ~8 ~ ~ ~ filtered #gm4_towering_trees:tree_placeable move
execute unless score $blocks_moved gm4_towering_trees_data matches 2376 run return fail

# optional feature
#

# place tree
execute store result score $tree_rotation gm4_towering_trees_data run random value 1..4
execute if score $tree_rotation gm4_towering_trees_data matches 1 run place template gm4_towering_trees:poplar/c3m ~-5 ~ ~-3
execute if score $tree_rotation gm4_towering_trees_data matches 2 run place template gm4_towering_trees:poplar/c3m ~6 ~ ~4 180
execute if score $tree_rotation gm4_towering_trees_data matches 3 run place template gm4_towering_trees:poplar/c3m ~4 ~ ~-5 clockwise_90
execute if score $tree_rotation gm4_towering_trees_data matches 4 run place template gm4_towering_trees:poplar/c3m ~-3 ~ ~6 counterclockwise_90

# mark as placed
scoreboard players set $tree_placed gm4_towering_trees_data 1
