# calculate modifiers for newly spawned spider
# @s = spider
# at @s
# run from mob/init/mob_type

# | Biome Modifiers
# snowy
execute if predicate {type:"minecraft:all_of",terms:[{type:"minecraft:random_chance",chance:0.15d},"gm4_monsters_unbound:biome/snowy"]} run function gm4_monsters_unbound:mob/init/mob_type/spider/gargantuan
# mountainous
execute if predicate {type:"minecraft:all_of",terms:[{type:"minecraft:random_chance",chance:0.4d},"gm4_monsters_unbound:biome/mountainous"]} run effect give @s speed infinite 0
# burned
execute if predicate {type:"minecraft:all_of",terms:[{type:"minecraft:random_chance",chance:0.5d},"gm4_monsters_unbound:biome/burned"]} run effect give @s fire_resistance infinite 0
# flowering 
execute if biome ~ ~ ~ lush_caves if predicate {type:"minecraft:random_chance",chance:0.5d} run function gm4_monsters_unbound:mob/init/mob_type/spider/lush_caves
# toxic
execute if entity @s[tag=!gm4_sr_extra_mob, predicate=gm4_monsters_unbound:biome/toxic] run function gm4_monsters_unbound:mob/init/mob_type/spider/toxic
# growth
execute if entity @s[tag=!gm4_sr_extra_mob, predicate=gm4_monsters_unbound:biome/growth] store success score $mob_extras gm4_sr_data run summon spider ~ ~ ~ {Tags:["gm4_sr_extra_mob"]}
execute if entity @s[tag=!gm4_sr_extra_mob, predicate=gm4_monsters_unbound:biome/growth] if predicate {type:"minecraft:random_chance",chance:0.6d} store success score $mob_extras gm4_sr_data run summon spider ~ ~ ~ {Tags:["gm4_sr_extra_mob"]}
# dripstone caves
execute if predicate {type:"minecraft:all_of",terms:[{type:"minecraft:random_chance",chance:0.1d},{type:"minecraft:location_check",predicate:{biomes:"dripstone_caves"}}]} run function gm4_monsters_unbound:mob/init/mob_type/spider/gargantuan
# underground
execute if predicate {type:"minecraft:all_of",terms:[{type:"minecraft:random_chance",chance:0.25d},"gm4_monsters_unbound:technical/underground"]} run function gm4_monsters_unbound:mob/init/mob_type/spider/underground/pick
