execute if score gm4_lore load.status matches 1 if score gm4_lore_minor load.status matches 5.. run function gm4_lore-1.5:algorithms/search
