execute if score gm4_lore load.status matches 1 unless score gm4_lore_minor load.status matches 5.. run scoreboard players set gm4_lore_minor load.status 5

execute unless score gm4_lore load.status matches 1.. run scoreboard players set gm4_lore_minor load.status 5
execute unless score gm4_lore load.status matches 1.. run scoreboard players set gm4_lore load.status 1
