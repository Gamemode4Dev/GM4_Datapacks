execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. run scoreboard players set gm4_balloon_animals load.status 1
execute if score gm4 load.status matches 1 if score gm4_minor load.status matches 10.. run scoreboard players set gm4_balloon_animals_minor load.status 4
execute unless score gm4 load.status matches 1.. run data modify storage gm4:log queue append value {type:"missing",module:"Balloon Animals",id:"gm4_balloon_animals",require:"Gamemode 4 Base",require_id:"gm4"}
execute if score gm4 load.status matches 1.. unless score gm4 load.status matches 1 run data modify storage gm4:log queue append value {type:"version_conflict",module:"Balloon Animals",id:"gm4_balloon_animals",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute if score gm4 load.status matches 1 unless score gm4_minor load.status matches 10.. run data modify storage gm4:log queue append value {type:"version_conflict",module:"Balloon Animals",id:"gm4_balloon_animals",require:"Gamemode 4 Base",require_id:"gm4",require_ver:"1.10.0"}
execute unless score gm4_balloon_animals load.status matches 1.. run scoreboard players set gm4_balloon_animals load.status -1

execute if score gm4_balloon_animals load.status matches 1 run function gm4_balloon_animals:init
execute unless score gm4_balloon_animals load.status matches 1 run schedule clear gm4_balloon_animals:main
