scoreboard objectives add gm4_potion_id dummy
scoreboard objectives add gm4_potion_time dummy
execute unless score potion_tracking gm4_earliest_version matches ..105000 run scoreboard players set potion_tracking gm4_earliest_version 105000


data modify storage gm4:log versions append value {id:"gm4_potion_tracking",module:"lib_potion_tracking",version:"1.5.X",from:"Lightning in a Bottle"}
