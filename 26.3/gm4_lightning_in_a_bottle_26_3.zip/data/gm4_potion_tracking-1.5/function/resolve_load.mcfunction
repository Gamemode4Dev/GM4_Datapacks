execute if score gm4_potion_tracking load.status matches 1 if score gm4_potion_tracking_minor load.status matches 5 run function gm4_potion_tracking-1.5:load
