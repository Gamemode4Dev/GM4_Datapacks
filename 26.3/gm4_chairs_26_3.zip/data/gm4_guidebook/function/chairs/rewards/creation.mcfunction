tellraw @s ["",{translate:"text.gm4.guidebook.discovered",fallback:"%1$s has discovered a guidebook page from %2$s",with:[{selector:"@s"},{text:"[Chairs]",color:"#4AA0C7",hover_event:{action:"show_text",value:[{text:"Chairs",color:"#4AA0C7"},{text:"\n"},{translate:"text.gm4.guidebook.module_desc.chairs",fallback:"Place a saddle on a stair to have a chair to sit on!",italic:true,color:"gray"}]}}]}]
advancement grant @s only gm4_guidebook:chairs/display/creation
function gm4_guidebook:chairs/rewards/unlock/creation
