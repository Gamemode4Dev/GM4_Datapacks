# converts an existing cow into a red mooshroom
# @s = cow to be converted
# at @s (after move)
# run from gm4_shroomites:spore/move/postmovement

# turn cow into a red mooshroom
summon mooshroom ~ ~ ~ {Type:"red",Tags:["gm4_new_shroomite_mooshroom"]}
teleport @e[type=mooshroom, tag=gm4_new_shroomite_mooshroom, limit=1, distance=0] @s
data modify entity @e[type=mooshroom, tag=gm4_new_shroomite_mooshroom, limit=1, distance=0] {} merge from entity @s {}
execute as @e[type=mooshroom, limit=1, distance=0] run function gm4_shroomites:mooshroom/initialize/red

# particles and sound
particle minecraft:mycelium ~ ~0.8 ~ 0.4 0.4 0.4 0 50
playsound minecraft:block.chorus_flower.grow hostile @a[distance=..10] ~ ~ ~ 0.625
particle minecraft:block{block_state:"minecraft:red_mushroom_block"} ~ ~1 ~ 0.3 0.3 0.3 20 20

# add to age
scoreboard players operation @s gm4_shroom_data += #conversion_cost gm4_shroom_data

# kill cow
tp @s ~ -4096 ~
