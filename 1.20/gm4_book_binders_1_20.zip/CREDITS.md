# Credits

## Creators
- [Bloo](https://twitter.com/Bloo_dev)
- [Sparks](https://twitter.com/SparksTheGamer)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
