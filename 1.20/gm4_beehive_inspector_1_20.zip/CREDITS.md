# Credits

## Creator
- [Misode](https://twitter.com/misode_)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
