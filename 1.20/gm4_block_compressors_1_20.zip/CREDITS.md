# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- SunderB
- [Misode](https://twitter.com/misode_)
- [JP12](https://github.com/jpeterik12)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [kyrkis](http://discordapp.com/users/287287322360414218)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
