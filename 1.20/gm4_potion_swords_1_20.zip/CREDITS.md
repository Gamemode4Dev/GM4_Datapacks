# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
