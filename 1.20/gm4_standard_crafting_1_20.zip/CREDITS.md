# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
