# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- SunderB

## Icon Design
- Hozz
