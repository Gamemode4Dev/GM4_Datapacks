# Credits

## Creator
- [15Redstones](https://twitter.com/15Redstones)

## Updated by
- [Misode](https://twitter.com/misode_)
- TheEpyonProject

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
