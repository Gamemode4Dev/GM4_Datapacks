# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
- TheEpyonProject

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
