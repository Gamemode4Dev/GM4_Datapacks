# Credits

## Creator
- [Fyid](https://twitter.com/FyidRants)

## Updated by
- [Misode](https://twitter.com/misode_)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
