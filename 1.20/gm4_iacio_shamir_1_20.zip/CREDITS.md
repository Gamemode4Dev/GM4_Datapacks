# Credits

## Creator
- [Denniss](https://twitter.com/Dennis2p_)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
