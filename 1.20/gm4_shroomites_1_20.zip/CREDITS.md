# Credits

## Creators
- [Sparks](https://twitter.com/SelcouthSparks)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Bloo](https://twitter.com/Bloo_dev)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
