# Credits

## Creators
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [JP12](https://github.com/jpeterik12)

## Textures by
- Vilder50
- Hozz

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
