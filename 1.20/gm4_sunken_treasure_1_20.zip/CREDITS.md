# Credits

## Creators
- [Wumpacraft](https://twitter.com/wumpacraft)
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
- [Lue](https://github.com/Luexa)

## Icon Design
- Hozz
