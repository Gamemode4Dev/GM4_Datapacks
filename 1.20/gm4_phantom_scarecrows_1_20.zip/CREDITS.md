# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Inspired by
- [Chopper2112](https://twitter.com/TheChopper2112)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
