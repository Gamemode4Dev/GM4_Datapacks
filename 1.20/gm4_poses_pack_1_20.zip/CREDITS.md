# Credits

## Creators
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- [Misode](https://twitter.com/misode_)
- [Denniss](https://twitter.com/Dennis2p_)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
