# Credits

## Creator
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- Vilder50
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
