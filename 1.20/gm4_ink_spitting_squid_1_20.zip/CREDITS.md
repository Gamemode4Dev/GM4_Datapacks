# Credits

## Creator
- [Energyxxer](https://youtube.com/user/Energyxxer)

## Updated by
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
