# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz

## Textures By
- [kyrkis](http://discordapp.com/users/287287322360414218)
