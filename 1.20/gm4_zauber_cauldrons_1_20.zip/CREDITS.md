# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)
- [Lue](https://github.com/Luexa)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Pixel Art
- [Memo](https://linktr.ee/miraku_memo)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
