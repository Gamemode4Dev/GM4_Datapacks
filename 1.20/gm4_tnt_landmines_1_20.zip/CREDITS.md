# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated By
- kruthers
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz
