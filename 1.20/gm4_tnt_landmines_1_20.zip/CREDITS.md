# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated By
- kruthers
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- Hozz
