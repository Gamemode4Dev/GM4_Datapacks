# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated By
- [Andante](https://twitter.com/andantett)
- [Kroppeb](https://twitter.com/kroppeb)
- [Misode](https://twitter.com/misode_)
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures By
- [kyrkis](http://discordapp.com/users/287287322360414218)

## Icon Design
- Hozz
