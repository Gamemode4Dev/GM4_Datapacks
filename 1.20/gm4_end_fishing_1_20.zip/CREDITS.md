# Credits

## Creator
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
