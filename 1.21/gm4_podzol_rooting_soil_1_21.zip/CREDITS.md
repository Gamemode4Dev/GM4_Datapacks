# Credits

## Creator
- [Bloo](https://twitter.com/Bloo_dev)

## Updated by
- [Misode](https://twitter.com/misode_)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
