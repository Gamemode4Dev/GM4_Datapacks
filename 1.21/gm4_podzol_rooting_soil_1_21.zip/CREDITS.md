# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [Misode](https://bsky.app/profile/misode.dev)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
