# Credits

## Creator
- Elemend

## Updated by
- [Misode](https://twitter.com/misode_)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- [Sparks](https://twitter.com/SelcouthSparks)
