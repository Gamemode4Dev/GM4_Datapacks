# Credits

## Creator
- [Thanathor](https://twitter.com/The_Thanathor)
