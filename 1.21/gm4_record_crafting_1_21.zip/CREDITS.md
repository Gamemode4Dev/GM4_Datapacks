# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [Bloo](https://twitter.com/Bloo_dev)

## Icon Design
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)
