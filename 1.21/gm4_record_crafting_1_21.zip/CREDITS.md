# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
