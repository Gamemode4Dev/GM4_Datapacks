# Credits

## Creator
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)

## Textures by
- Vilder50

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
