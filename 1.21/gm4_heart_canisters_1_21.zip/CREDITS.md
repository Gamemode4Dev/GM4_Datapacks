# Credits

## Creators
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
- SpiderRobotMan

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [Misode](https://bsky.app/profile/misode.dev)
- TheEpyonProject

## Textures by
- Jonpot

## Icon Design
- Hozz
