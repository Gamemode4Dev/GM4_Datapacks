# Credits

## Creator
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [SpecialBuilder32](https://bsky.app/profile/specialbuilder32.bsky.social)
- [BPR](https://bsky.app/profile/bpr02.com)

## Icon Design
- Hozz
