# Credits

## Creators
- [Wumpacraft](https://twitter.com/wumpacraft)
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)

## Updated by
- [BPR](https://bsky.app/profile/bpr02.com)
- [Lue](https://github.com/Luexa)

## Icon Design
- Hozz
