# Credits

## Creator
- [Bloo](https://bsky.app/profile/bloo.boo)

## Updated by
- [Bloo](https://bsky.app/profile/bloo.boo)
- [Lue](https://github.com/Luexa)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures
- [Memo](https://linktr.ee/miraku_memo)
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
