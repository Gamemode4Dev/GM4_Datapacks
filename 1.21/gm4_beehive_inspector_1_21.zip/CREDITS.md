# Credits

## Creator
- [Misode](https://bsky.app/profile/misode.dev)

## Icon Design
- [BPR](https://bsky.app/profile/bpr02.com)
