# Credits

## Creator
- [SirSheepe](https://bsky.app/profile/sirsheepe.bsky.social)

## Updated by
- [Modulorium](https://www.modulorium.dev)
- [BPR](https://bsky.app/profile/bpr02.com)

## Textures by
- [Kyrius](https://bsky.app/profile/kyriuspixels.bsky.social)

## Icon Design
- [Sparks](https://bsky.app/profile/selcouthsparks.bsky.social)
