# Credits

## Creator
- [Sparks](https://twitter.com/SelcouthSparks)

## Updated by
- [Misode](https://twitter.com/misode_)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
