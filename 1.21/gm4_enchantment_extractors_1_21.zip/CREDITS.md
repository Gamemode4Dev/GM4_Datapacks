# Credits

## Creator
- [The8BitMonkey](https://youtube.com/the8bitmonkey)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Misode](https://twitter.com/misode_)
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [Kyrius](http://discordapp.com/users/287287322360414218)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
