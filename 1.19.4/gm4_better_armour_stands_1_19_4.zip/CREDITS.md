# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Misode](https://twitter.com/misode_)
- [Denniss](https://twitter.com/Dennis2p_)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
