# Credits

## Creator
- [Kroppeb](https://twitter.com/kroppeb)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
